# Chord Detector
A minimalistic chord detection application created with Tkinter in Python.

The Chord detection algorithm uses Harmonic Product Spectrum to generate Pitch Class Profile (Chromagram). The PCP is then used for template-matching and getting the chord.
